package Kuis2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class BiodataKuis2 extends JFrame{
    private JPanel panel1;
    private JTextField nikText;
    private JTextField namaText;
    private JComboBox pendidikanComboBox;
    private JCheckBox bacaCheckBox;
    private JTextField alamatText;
    private JCheckBox makanCheckBox;
    private JCheckBox tidurCheckBox;
    private JRadioButton perempuanRadioButton;
    private JRadioButton LakiRadioButton;
    private JButton daftarButton;
    private JTextField noTelptextField;
    private JFormattedTextField tglLahirTextField;
    private JFormattedTextField ipkTextField;
    private JFrame frame;
    private ButtonGroup buttonGroup2;

    private void createUIComponents() {
        LakiRadioButton.setActionCommand("Laki-laki");
        perempuanRadioButton.setActionCommand("Perempuan");

        buttonGroup2 = new ButtonGroup();
        buttonGroup2.add(LakiRadioButton);
        buttonGroup2.add(perempuanRadioButton);
    }

    private int calculateAge(Date birthDate) {
        Calendar birthCalendar = Calendar.getInstance();
        birthCalendar.setTime(birthDate);

        Calendar today = Calendar.getInstance();

        int age = today.get(Calendar.YEAR) - birthCalendar.get(Calendar.YEAR);

        if (today.get(Calendar.MONTH) < birthCalendar.get(Calendar.MONTH) ||
                (today.get(Calendar.MONTH) == birthCalendar.get(Calendar.MONTH) && today.get(Calendar.DAY_OF_MONTH) < birthCalendar.get(Calendar.DAY_OF_MONTH))) {
            age--;
        }

        return age;
    }

    public BiodataKuis2() {
        createUIComponents();

        daftarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                StringBuilder sb = new StringBuilder();

                boolean isValid = true;

                if (nikText.getText().trim().equals("")) {
                    sb.append("NIK harus diisi!\n");
                    isValid = false;
                }
                if (namaText.getText().trim().equals("")) {
                    sb.append("Nama harus diisi!\n");
                    isValid = false;
                }
                if (alamatText.getText().trim().equals("")) {
                    sb.append("Alamat harus diisi!\n");
                    isValid = false;
                }
                if (pendidikanComboBox.getSelectedItem() == null ||
                        pendidikanComboBox.getSelectedItem().equals("SD") ||
                        pendidikanComboBox.getSelectedItem().equals("SMP") ||
                        pendidikanComboBox.getSelectedItem().equals("SMA")) {
                    sb.append("Pendidikan tidak memenuhi syarat\n");
                    isValid = false;
                }
                if (buttonGroup2.getSelection() == null) {
                    sb.append("Gender harus dipilih!\n");
                    isValid = false;
                }
                if (!bacaCheckBox.isSelected() && !makanCheckBox.isSelected() && !tidurCheckBox.isSelected()) {
                    sb.append("Minimal satu hobi harus dipilih!\n");
                    isValid = false;
                }
                if (noTelptextField.getText().trim().equals("")) {
                    sb.append("No Telp harus diisi!\n");
                    isValid = false;
                }
                if (tglLahirTextField.getText().trim().equals("")) {
                    sb.append("Tgl Lahir harus diisi!\n");
                    isValid = false;
                } else {
                    String dobText = tglLahirTextField.getText().trim();
                    if (!dobText.isEmpty()) {
                        try {
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date birthDate = sdf.parse(dobText);
                            int age = calculateAge(birthDate);

                            if (age < 18) {
                                sb.append("Umur tidak mencukupi!\n");
                                isValid = false;
                            }
                        } catch (ParseException ex) {
                            sb.append("Format tanggal lahir tidak sesuai! dd/MM/yyyy!\n");
                            isValid = false;
                        }
                    }
                }
                if (ipkTextField.getText().trim().equals("")) {
                    sb.append("IPK harus diisi!\n");
                    isValid = false;
                    System.out.println("ipk");
                } else if (Double.parseDouble(ipkTextField.getText()) < 3.01) {
                    sb.append("IPK minimal 3.01!\n");
                    isValid = false;
                    System.out.println("ipk");
                }

                if (isValid) {
                    JOptionPane.showMessageDialog(BiodataKuis2.this, "Anda Berhasil Mendaftar", "Informasi", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(BiodataKuis2.this, sb, "Biodata", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });


        noTelptextField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char inputChar = e.getKeyChar();
                if (inputChar == KeyEvent.VK_BACK_SPACE) {
                    return;
                }
                if (!Character.isDigit(inputChar)) {
                    e.consume();
                    JOptionPane.showMessageDialog(null, "Harus diisi dengan angka!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        ipkTextField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                super.keyReleased(e);
                String text = ipkTextField.getText() + e.getKeyChar();
                if (e.getKeyChar() == KeyEvent.VK_BACK_SPACE) {
                    return;
                }
                try {
                    if (!text.isEmpty()) {
                        double ipk = Double.parseDouble(text);

                        if (ipk < 0.00 || ipk > 4.00) {
                            e.consume();
                            JOptionPane.showMessageDialog(null, "IPK tidak valid. Harus antara 0.00 dan 4.00.", "Peringatan", JOptionPane.WARNING_MESSAGE);
                        }
                    }
                } catch (NumberFormatException ex) {
                    e.consume();
                    JOptionPane.showMessageDialog(null, "Harus diisi dengan angka!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Biodata");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(new BiodataKuis2().panel1);
        frame.pack();
        frame.setVisible(true);
    }
}

